/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dfsdm.h"
#include "i2c.h"
#include "quadspi.h"
#include "spi.h"
#include "usart.h"
#include "usb_otg.h"
#include "gpio.h"
#include "arm_const_structs.h"
#include "arm_math_types.h"
#include "arm_common_tables.h"
#include "arm_const_structs.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "arm_math.h"  // CMSIS-DSP float32_t
#include <math.h>
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define SAMPLE_RATE_HZ 100
#define SAMPLE_COUNT 256
#define FFT_SIZE 256
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
float32_t accel_buffer[SAMPLE_COUNT];
float32_t fft_input[FFT_SIZE];
float32_t fft_output[FFT_SIZE];
float32_t mag[FFT_SIZE / 2];
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

extern I2C_HandleTypeDef hi2c2;
extern UART_HandleTypeDef huart1;

int __io_putchar(int ch)
{
  HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
  return ch;
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
 int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_I2C2_Init();
  MX_USART1_UART_Init();

  // check WHO_AM_I
  uint8_t who_am_i = 0;
  HAL_StatusTypeDef status;
  status = HAL_I2C_Mem_Read(&hi2c2, 0xD4, 0x0F, I2C_MEMADD_SIZE_8BIT, &who_am_i, 1, HAL_MAX_DELAY);
  if (status != HAL_OK || who_am_i != 0x6A)
  {
    while (1)
    {
      HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_14); //LD2 blinks to indicate a read failure
      HAL_Delay(200);
    }
  }

  // Enable accelerometer (CTRL1_XL = 0x40)
  uint8_t ctrl1 = 0x40;
  HAL_I2C_Mem_Write(&hi2c2, 0xD4, 0x10, I2C_MEMADD_SIZE_8BIT, &ctrl1, 1, HAL_MAX_DELAY);

  // Initializing an FFT Instance
  arm_rfft_fast_instance_f32 fft_instance;
  arm_rfft_fast_init_f32(&fft_instance, FFT_SIZE);

  // === Testing limited to 10 rounds ===
  for (int round = 0; round < 10; round++)
  {
    // Sampling
    int16_t acc_x, acc_y, acc_z;
    uint8_t buffer[6];

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET); // LD2 is on to indicate that sampling is in progress


    //This part detects hand shaking, but for the sake of testing I use an analog signal
    /*for (int i = 0; i < SAMPLE_COUNT; i++) {
    HAL_I2C_Mem_Read(&hi2c2, 0xD4, 0x28, I2C_MEMADD_SIZE_8BIT, buffer, 6, HAL_MAX_DELAY);
    acc_x = (int16_t)(buffer[1] << 8 | buffer[0]);
    acc_y = (int16_t)(buffer[3] << 8 | buffer[2]);
    acc_z = (int16_t)(buffer[5] << 8 | buffer[4]);
    float32_t mag = sqrtf((float32_t)(acc_x * acc_x + acc_y * acc_y + acc_z * acc_z));
    accel_buffer[i] = mag;
    HAL_Delay(1000 / SAMPLE_RATE_HZ);
} */
    //analog signal

    for (int i = 0; i < SAMPLE_COUNT; i++) {
      float t = (float)i / SAMPLE_RATE_HZ;
      accel_buffer[i] = 1000.0f * sinf(2.0f * 3.1415926f * 6.0f * t); //6HZ sine wave
      HAL_Delay(1000 / SAMPLE_RATE_HZ); 
    }
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET); // LD2 extinguished indicates that sampling is complete



    // FFT Input Preparation
    for (int i = 0; i < FFT_SIZE; i++) {
      fft_input[i] = accel_buffer[i];
    }

    // Execute FFT
    arm_rfft_fast_f32(&fft_instance, fft_input, fft_output, 0);

    // Amplitude calculations
    for (int i = 0; i < FFT_SIZE / 2; i++) {
      float32_t real = fft_output[2 * i];
      float32_t imag = fft_output[2 * i + 1];
      mag[i] = sqrtf(real * real + imag * imag);
    }

   

    // Finding the main frequency
    int max_index = 1;
    float32_t max_value = mag[1];
    for (int i = 2; i < FFT_SIZE / 2; i++) {
      if (mag[i] > max_value) {
        max_value = mag[i];
        max_index = i;
      }
    }

    float32_t dominant_freq = ((float32_t)max_index * SAMPLE_RATE_HZ) / FFT_SIZE;

    //Serial outputs are for testing purposes only and are subsequently removed on request
    if (dominant_freq > 3.0f && dominant_freq < 5.0f)
      printf("Detected: Tremor\r\n");
    else if (dominant_freq >= 5.0f && dominant_freq < 7.0f)
      printf("Detected: Dyskinesia\r\n");
    else
      printf("No abnormal frequency detected.\r\n");

    HAL_Delay(500); // round
  }

  // Lights out at the end of all rounds and park here.
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
  printf("FFT test finished.\r\n");

  while (1)
  {
  }
}


 

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 40;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable MSI Auto calibration
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
